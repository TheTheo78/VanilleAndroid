package fr.test.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;
import java.text.SimpleDateFormat;

import fr.test.vanillemobile.R;
import fr.test.vanillemobile.model.Catalogue;
import fr.test.vanillemobile.model.Categorie;
import fr.test.vanillemobile.model.Commande;
import fr.test.vanillemobile.outils.LectureFichierJson;
import fr.test.vanillemobile.outils.TraitementJson;
import fr.test.vanillemobile.repository.CatalogueRepository;

public class MainActivity extends AppCompatActivity {
    private Catalogue catalogueEnCours;
    private Button btProduits;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btProduits = findViewById(R.id.btProduits);
        Commande commandeEnCours = Commande.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(commandeEnCours.getDateCommande());

        Toast toast = Toast.makeText(getApplicationContext(),"Affichage test de la commande " + formattedDate + " montant de la commande " + String.valueOf(commandeEnCours.getTotalCommande()),Toast.LENGTH_LONG);
        toast.show();

        try {
            String texte = LectureFichierJson.getDonneesJson(this);
            catalogueEnCours = TraitementJson.LectureDonneesDepuisJson(texte, this);
            ////// TEST IV Recup catalogue
            CatalogueRepository.EnregistrerLeCatalogue(catalogueEnCours, this);

            btProduits.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, ListeProduitsActivity.class);
                    startActivity(intent);
                }
            });





        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }


    }
}