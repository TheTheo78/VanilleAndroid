package fr.test.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.time.LocalDate;
import java.util.HashMap;

import fr.test.vanillemobile.R;
import fr.test.vanillemobile.model.Categorie;
import fr.test.vanillemobile.model.Commande;
import fr.test.vanillemobile.model.Produit;
import fr.test.vanillemobile.repository.CatalogueRepository;

public class ProduitActivity extends AppCompatActivity {

    private TextView txtDescription;
    private EditText editQte;
    private TextView txtPrixUnitaire;
    private TextView txtPrixTotal;
    private Button btCalculer;
    private Button btAjouter;
    private Button btCommande;
    private Button btBonbons;
    private Commande commandeEnCours;
    private Produit produitSelectionnee;

    private void init(){
        txtDescription = findViewById(R.id.txtDescription);
        txtPrixUnitaire = findViewById(R.id.txtPrixUnitaire);
        txtPrixTotal = findViewById(R.id.txtPrixTotal);
        editQte = findViewById(R.id.editQte);
        btCalculer = findViewById(R.id.btCalculer);
        btAjouter = findViewById(R.id.btAjouter);
        btCommande = findViewById(R.id.btCommande);
        btBonbons = findViewById(R.id.btBonbon);
        commandeEnCours = Commande.getInstance();
        Bundle b = getIntent().getExtras();
        if(b!=null){
            int pos = b.getInt("index");
            produitSelectionnee = CatalogueRepository.RecupererLeCatalogue(this).getLesProduits().get(pos);
        }
        txtPrixUnitaire.setText(String.valueOf(produitSelectionnee.getPrixActuel(LocalDate.now())));
        txtDescription.setText(produitSelectionnee.getDescription());


        btCalculer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!editQte.getText().toString().isEmpty() && Integer.parseInt(editQte.getText().toString()) > 0){
                int qte;
                float prix;
                qte = Integer.parseInt(editQte.getText().toString());
                prix = Float.parseFloat(txtPrixUnitaire.getText().toString());
                txtPrixTotal.setText(String.valueOf(qte*prix));
            }
                else{
                    Toast.makeText(view.getContext(), "Veillez entrer une quantité", Toast.LENGTH_LONG).show();
                }
            }
        });

        btAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!editQte.getText().toString().isEmpty() && Integer.parseInt(editQte.getText().toString()) > 0){
                int qte = Integer.parseInt(editQte.getText().toString());
                HashMap<Produit, Integer> lignesCommande = commandeEnCours.getLignesCommande();
                lignesCommande.put(produitSelectionnee,qte);
                commandeEnCours.setLignesCommande(lignesCommande);
                Log.i("ajouter", "onClick:");
                Log.i("ajouter", commandeEnCours.getLignesCommande().toString());
                }
                else{
                    Toast.makeText(view.getContext(), "Veillez entrer une quantité", Toast.LENGTH_LONG).show();
                }
            }
        });

        btCommande.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(view.getContext(), FactureActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btBonbons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(view.getContext(), ListeProduitsActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produit);
        init();
    }
}