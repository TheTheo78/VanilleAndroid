package fr.test.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import fr.test.vanillemobile.R;
import fr.test.vanillemobile.model.Client;
import fr.test.vanillemobile.model.Commande;
import fr.test.vanillemobile.model.Produit;
import fr.test.vanillemobile.outils.Serializer;
import fr.test.vanillemobile.repository.ClientRepository;

public class FactureActivity extends AppCompatActivity {

    private EditText editNom;
    private EditText editPrenom;
    private EditText editAdresse;
    private EditText editCP;
    private EditText editVille;
    private EditText editMail;
    private Button btEnvoyer;
    private Button btAnnuler;
    private Button btModifier;
    private TextView txtMontant;
    private Commande commandeEnCours;

    private void init(){
        commandeEnCours = Commande.getInstance();
        editAdresse = findViewById(R.id.editAdresse);
        editCP = findViewById(R.id.editCP);
        editMail = findViewById(R.id.editMail);
        editNom = findViewById(R.id.editNom);
        editPrenom = findViewById(R.id.editPrenom);
        editVille = findViewById(R.id.editVille);
        txtMontant = findViewById(R.id.txtMontant);
        btEnvoyer = findViewById(R.id.btEnvoyer);
        btAnnuler = findViewById(R.id.btAnnuler);
        btModifier = findViewById(R.id.btModifier);
        txtMontant.setText(Float.toString(commandeEnCours.getTotalCommande()));
        Log.i("test liste total", commandeEnCours.toString());
        final Context context = this;
        recupClient();
        btEnvoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Client leClient = new Client(editNom.getText().toString(), editPrenom.getText().toString(), editAdresse.getText().toString(), editCP.getText().toString(), editVille.getText().toString(), editMail.getText().toString());
                commandeEnCours.setLeClient(leClient);
                ClientRepository.EnregistrerLeClient(leClient, view.getContext());
                String montant = Float.toString(commandeEnCours.getTotalCommande());
                Log.i("envoyer","onClick " + commandeEnCours.getLeClient().toString());
                Toast.makeText(view.getContext(), "Vous venez d'envoyer la confirmation de votre commande. Le total de votre commande est de " + montant + " €", Toast.LENGTH_LONG).show();
            }
        });
        btAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HashMap<Produit, Integer> listeVide = new HashMap<Produit, Integer>() ;
                commandeEnCours.setLignesCommande(listeVide);
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        btModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent  = new Intent(view.getContext(), ListeProduitsActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void recupClient(){
        if(null != Serializer.deSerialize(ClientRepository.getNomFichier(), this)){
            Client leClient = (Client)Serializer.deSerialize(ClientRepository.getNomFichier(), this);
            editNom.setText(leClient.getNomClient());
            editPrenom.setText(leClient.getPrenom());

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facture);
        init();

    }
}