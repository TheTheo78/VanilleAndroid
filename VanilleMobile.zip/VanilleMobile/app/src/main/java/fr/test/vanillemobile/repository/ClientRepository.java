package fr.test.vanillemobile.repository;

import android.content.Context;
import android.view.View;

import java.io.Serializable;

import fr.test.vanillemobile.model.Client;
import fr.test.vanillemobile.outils.Serializer;

public class ClientRepository {


    private static final String nomFichier = "saveClient";

    public static void EnregistrerLeClient(Client leClient, Context context){
        Serializer.serialize(nomFichier, leClient, context);
    }

    public static Client RecupererLeClient(Context context){
        return (Client)Serializer.deSerialize(nomFichier,context);
    }

    public static String getNomFichier() {
        return nomFichier;
    }

}
