package fr.test.vanillemobile.outils;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;

import fr.test.vanillemobile.model.Catalogue;
import fr.test.vanillemobile.model.Categorie;
import fr.test.vanillemobile.model.Produit;
import fr.test.vanillemobile.model.Promotion;
import fr.test.vanillemobile.repository.CatalogueRepository;

public abstract class TraitementJson {
    public static Catalogue LectureDonneesDepuisJson(String jstring, Context context) throws JSONException{
        Catalogue leCatalogue;
        Categorie categorieLue;
        Promotion promotionLue;
        Produit produitLue;

        leCatalogue = new Catalogue("1", "catalogue en cours", LocalDate.now());

        JSONObject jsonObject = new JSONObject(jstring);
        JSONArray jCategories = jsonObject.getJSONArray("categories");
        JSONArray jPromotions = jsonObject.getJSONArray("promotions");
        JSONArray jProduits = jsonObject.getJSONArray("produits");

        //traitement categories
        for (int i = 0; i < jCategories.length(); i++) {
            categorieLue = new Categorie(jCategories.getJSONObject(i).getString("id"), jCategories.getJSONObject(i).getString("description"));
            leCatalogue.getLesCategories().add(categorieLue);
            Log.i("ajout", categorieLue.toString());
        }

        //traitement promotions
        for (int i = 0; i< jPromotions.length(); i++){
            LocalDate debutDate = LocalDate.parse(jPromotions.getJSONObject(i).getString("debutPromo"));
            LocalDate finDate = LocalDate.parse(jPromotions.getJSONObject(i).getString("finPromo"));
            float remise = Float.parseFloat(jPromotions.getJSONObject(i).getString("remise"));
            promotionLue = new Promotion(jPromotions.getJSONObject(i).getString("id"),jPromotions.getJSONObject(i).getString("libelle"), debutDate, finDate , remise);
            leCatalogue.getLesPromos().add(promotionLue);
            Log.i("ajout", promotionLue.toString());
        }

        //traitement produits
        for (int i = 0; i< jProduits.length(); i++){
            categorieLue = leCatalogue.getLesCategories().get(jProduits.getJSONObject(i).getInt("categorie"));
            float prix = Float.parseFloat(jProduits.getJSONObject(i).getString("prix"));
            produitLue = new Produit(jProduits.getJSONObject(i).getString("PDT_id"),jProduits.getJSONObject(i).getString("description"), jProduits.getJSONObject(i).getString("image"), prix , categorieLue);
            leCatalogue.getLesProduits().add(produitLue);
            if(!jProduits.getJSONObject(i).isNull("promo")){
                int position = jProduits.getJSONObject(i).getInt("promo");
                promotionLue = leCatalogue.getLesPromos().get(position);
                produitLue.getLesPromos().add(promotionLue);
            }
            Log.i("ajout", produitLue.toString());
        }
        CatalogueRepository.EnregistrerLeCatalogue(leCatalogue, context);
        return leCatalogue;

    }

}
