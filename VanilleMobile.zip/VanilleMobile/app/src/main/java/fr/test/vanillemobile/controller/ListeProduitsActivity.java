package fr.test.vanillemobile.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import fr.test.vanillemobile.R;
import fr.test.vanillemobile.model.Catalogue;
import fr.test.vanillemobile.model.Produit;
import fr.test.vanillemobile.repository.CatalogueRepository;

public class ListeProduitsActivity extends AppCompatActivity {

    private ListView lstProduits;
    private List<Produit> lesProduits = new ArrayList<Produit>();

    private void init(){
        lstProduits = findViewById(R.id.lstProduits);
        lesProduits = CatalogueRepository.RecupererLeCatalogue(this).getLesProduits();
        ArrayAdapter<Produit> itemsAdapteur = new ArrayAdapter<Produit>(this, android.R.layout.simple_list_item_1, lesProduits);
        lstProduits.setAdapter(itemsAdapteur);

        lstProduits.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(ListeProduitsActivity.this, ProduitActivity.class);
                intent.putExtra("index", i);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_produits);
        init();
    }

}