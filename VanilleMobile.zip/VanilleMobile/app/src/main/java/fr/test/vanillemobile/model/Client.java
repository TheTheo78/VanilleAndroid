package fr.test.vanillemobile.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Client implements Serializable {

        private String nomClient;
        private String prenom;
        private String adresse;
        private String cpClient;
        private String villeClient;
        private String mailClient;

        public Client(String nomClient, String prenom, String adresse, String cpClient, String villeClient, String mailClient){
                super();
                this.nomClient = nomClient;
                this.prenom = prenom;
                this.adresse = adresse;
                this.cpClient = cpClient;
                this.villeClient = villeClient;
                this.mailClient = mailClient;
        }

        public String getAdresse() {
                return adresse;
        }

        public String getCpClient() {
                return cpClient;
        }

        public String getMailClient() {
                return mailClient;
        }

        public String getNomClient() {
                return nomClient;
        }

        public String getPrenom() {
                return prenom;
        }

        public String getVilleClient() {
                return villeClient;
        }

        public void setCpClient(String cpClient) {
                this.cpClient = cpClient;
        }

        public void setAdresse(String adresse) {
                this.adresse = adresse;
        }

        public void setMailClient(String mailClient) {
                this.mailClient = mailClient;
        }

        public void setNomClient(String nomClient) {
                this.nomClient = nomClient;
        }

        public void setPrenom(String prenom) {
                this.prenom = prenom;
        }

        public void setVilleClient(String villeClient) {
                this.villeClient = villeClient;
        }

        /// <summary>
        /// renvoie l'id la description et le prix du produit correspondant à la date
        /// affiche le prix promotionnel suivi du mot PROMO lorsque le produit est en promotion
        /// </summary>
        /// <param name="date">date de prise en compte du prix du produit</param>
        /// <returns>chaine représentant le produit</returns>
        @Override
        public String toString()
        {
                String chaine = nomClient + " " + prenom + " " + adresse + " " + cpClient + " " + villeClient + " " + mailClient;
                return chaine;
        }
}
