package fr.test.vanillemobile.model;

import java.io.Serializable;

public class Categorie implements Serializable {
    private String id;
    private String libelle;
    public String getLibelle() {
        return libelle;
    }
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
    public Categorie(String id, String libelle) {
        super();
        this.id = id;
        this.libelle = libelle;
    }

    @Override
    public String toString() {
        return "Categorie{" +
                "id='" + id + '\'' +
                ", libelle='" + libelle + '\'' +
                '}';
    }
}
