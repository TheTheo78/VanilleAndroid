package com.example.tp11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.tp11.model.Categorie;
import com.example.tp11.model.Commande;
import com.example.tp11.model.Produit;

import java.time.LocalDate;

public class ProduitActivity extends AppCompatActivity {

    private EditText et_quantite;
    private Commande commandeEnCours;
    private Produit produitSelectionne;
    private TextView tv_prixUnitAff;
    private TextView tv_totalCalc;
    private Button bt_calc;
    private Button bt_Ajouter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produit);
        init();
    }

    private void init(){
        et_quantite = findViewById(R.id.et_quantite);
        tv_prixUnitAff = findViewById(R.id.tv_prixUnit);
        tv_totalCalc = findViewById(R.id.tv_totalCalc);
        bt_calc = findViewById(R.id.bt_calc);
        bt_Ajouter = findViewById(R.id.bt_ajouter);
        commandeEnCours = Commande.getInstance();
        Categorie chocolats = new Categorie("cho", "Chocolats");
        produitSelectionne = new Produit("B003", "Bonbons chocolat lot 3 kg", "", (float)3.0, chocolats);

        tv_prixUnitAff.setText(String.valueOf(produitSelectionne.getPrixActuel(LocalDate.now())));

        bt_calc.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view)
            {
                int qte;
                float prix;

                qte = Integer.parseInt(et_quantite.getText().toString());
                prix = Float.parseFloat(tv_prixUnitAff.getText().toString());
                tv_totalCalc.setText(String.valueOf(qte*prix));
            }
        });

        bt_Ajouter.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view)
            {
                int qte = Integer.parseInt(et_quantite.getText().toString());
                float prix = Float.parseFloat(tv_prixUnitAff.getText().toString());

                Log.i("ajouter", "onClick");
                Log.i("ajouter", commandeEnCours.toString());
            }
        });

    }
}