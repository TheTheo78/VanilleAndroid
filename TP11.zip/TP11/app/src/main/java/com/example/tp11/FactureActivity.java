package com.example.tp11;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tp11.ClientRepository.ClientRepository;
import com.example.tp11.model.Client;
import com.example.tp11.model.Commande;
import com.example.tp11.outils.Serializer;

public class FactureActivity extends AppCompatActivity {


    private EditText editTextFacture_nom;
    private EditText editTextFacture_prenom;
    private EditText editTextFacture_adresse;
    private EditText editTextFacture_cp;
    private EditText editTextFacture_ville;
    private EditText editTextFacture_mail;

    private TextView txt_nom;
    private TextView txt_prenom;
    private TextView txt_mail;
    private TextView txt_ville;
    private TextView txt_cp;
    private TextView txt_adresse;
    private TextView txtMontant;
    private TextView txtEuro;
    private TextView txtTotal;

    private Button btn_envoyer;

    private Commande commandeEnCours;

    private void init(){
        editTextFacture_adresse = findViewById(R.id.editTextFacture_adresse);
        editTextFacture_cp = findViewById(R.id.editTextFacture_cp);
        editTextFacture_prenom = findViewById(R.id.editTextFacture_prenom);
        editTextFacture_nom = findViewById(R.id.editTextFacture_nom);
        editTextFacture_ville = findViewById(R.id.editTextFacture_ville);
        editTextFacture_mail = findViewById(R.id.editTextFacture_mail);
        txtMontant = findViewById(R.id.txtMontant);
        btn_envoyer = findViewById(R.id.btn_envoyer);
        //txtMontant.setText("52.0");
        commandeEnCours = Commande.getInstance();
        //commandeEnCours.getTotalCommande();
        //String montantCommande = Commande.toString(commandeEnCours);
        txtMontant.setText(commandeEnCours.getTotalCommande());
        //txtMontant.setText("52,0");
        final Context context = this;
        recupClient();

        btn_envoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Création d'un client

                Client client = new Client(editTextFacture_nom.getText().toString(), editTextFacture_prenom.getText().toString(), editTextFacture_adresse.getText().toString(), editTextFacture_cp.getText().toString(), editTextFacture_ville.getText().toString(), editTextFacture_mail.getText().toString());
                //Ajout client à la commande
                commandeEnCours.leClient = client;

                Toast.makeText(view.getContext(), "Votre commande d'un montant de "+txtMontant.getText()+" a bien été envoyée ! Vous recevrez un mail de confirmation à l'adresse "+editTextFacture_mail.getText().toString(), Toast.LENGTH_SHORT).show();
                Log.i("envoyer", "onClick" + commandeEnCours.getLeClient());
            }
        });
    }

    private void recupClient(){
        if (null != Serializer.deSerialize((ClientRepository.getNomFichier(), this)) {
            Client leClient = (Client)Serializer.deSerialize(ClientRepository.getNomFichier(), this);
            editTextFacture_nom.setText(leClient.getNomClient());
            editTextFacture_prenom.setText(leClient.getPrenom());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facture);
        init();
    }
}