package com.example.tp11.ClientRepository;

import android.content.Context;

import com.example.tp11.model.Client;
import com.example.tp11.outils.Serializer;

public abstract class ClientRepository {

    public static String getNomFichier() {
        return nomFichier;
    }

    private static final String nomFichier = "saveClient";

    public static void EnregistrerLeClient(Client leClient, Context context){
        Serializer.serialize(nomFichier, leClient, context);
    }

    public static Client RecuperLeClent(Context context) {
        return (Client)Serializer.deSerialize(nomFichier, context);
    }




}
